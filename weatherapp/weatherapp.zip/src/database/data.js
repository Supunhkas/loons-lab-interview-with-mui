export const user = [
  {
    id: 1,
    email: "admin@gmail.com",
    name: "lonnsLab",
    password: "admin@123",
  },
];
